# Kiwi

Discord-like chat MVP with:
- real-time text chat
- voice calls
- video calls
- WebRTC peer connections
- mobile-friendly UI

## Important
GitHub Pages can host the frontend (`index.html`, `style.css`, `app.js`), but it cannot run `server.js`.
The WebSocket signaling server must run separately.

## Local test
1. Install Node.js.
2. Run `npm install`
3. Run `npm start`
4. Open `http://localhost:3000` in a browser.

For two devices, deploy `server.js` to a Node hosting provider and set `SIGNALING_URL` in `app.js` to your secure `wss://...` server URL.

For production calls, HTTPS/WSS is strongly recommended.
