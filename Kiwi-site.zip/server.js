const http=require("http");
const WebSocket=require("ws");
const crypto=require("crypto");
const port=process.env.PORT||3000;
const server=http.createServer((req,res)=>{
  res.writeHead(200,{"Content-Type":"text/plain; charset=utf-8"});
  res.end("Kiwi signaling server is running");
});
const wss=new WebSocket.Server({server});
const rooms=new Map();
function send(ws,msg){if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(msg))}
wss.on("connection",ws=>{
  ws.id=crypto.randomUUID(); ws.room=null; ws.name="User";
  ws.on("message",raw=>{
    let m;try{m=JSON.parse(raw)}catch{return}
    if(m.type==="join"){
      ws.room=m.room||"general";ws.name=m.name||"User";
      if(!rooms.has(ws.room))rooms.set(ws.room,new Set());
      const set=rooms.get(ws.room);
      const users=[...set].map(x=>({id:x.id,name:x.name}));
      send(ws,{type:"joined",id:ws.id,users});
      set.forEach(x=>send(x,{type:"user-joined",id:ws.id,name:ws.name,count:set.size+1}));
      set.add(ws); return;
    }
    const set=rooms.get(ws.room);if(!set)return;
    if(m.type==="message"){set.forEach(x=>send(x,{type:"message",name:ws.name,text:String(m.text||"").slice(0,1000),time:Date.now()}));return}
    if(["offer","answer","ice"].includes(m.type)){
      const target=[...set].find(x=>x.id===m.to);if(target)send(target,{...m,from:ws.id});return
    }
    if(m.type==="call-ready"&&m.from===undefined){set.forEach(x=>{if(x!==ws)send(x,{type:"call-ready",from:ws.id})})}
  });
  ws.on("close",()=>{
    const set=rooms.get(ws.room);if(!set)return;
    set.delete(ws);set.forEach(x=>send(x,{type:"user-left",id:ws.id,name:ws.name,count:set.size}));
    if(!set.size)rooms.delete(ws.room);
  });
});
server.listen(port,()=>console.log("Kiwi server listening on "+port));