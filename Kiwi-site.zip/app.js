const $=id=>document.getElementById(id);
let ws, name="", room="", localStream=null, peers=new Map(), myId="";
const config={iceServers:[{urls:"stun:stun.l.google.com:19302"},{urls:"stun:stun.cloudflare.com:3478"}]};
const SIGNALING_URL=window.KIWI_SIGNALING_URL || ((location.protocol==="https:"?"wss://":"ws://")+location.hostname+":3000");

$("join").onclick=()=>{
  name=$("name").value.trim()||"KiwiUser";
  room=$("room").value.trim()||"general";
  $("login").classList.add("hidden"); $("app").classList.remove("hidden");
  $("myName").textContent=name; $("myAvatar").textContent=name[0].toUpperCase();
  $("roomLabel").textContent=room; $("headRoom").textContent=room;
  connect();
};

function connect(){
  try{ws=new WebSocket(SIGNALING_URL)}catch(e){setStatus("Ошибка соединения");return}
  ws.onopen=()=>{setStatus("● онлайн"); ws.send(JSON.stringify({type:"join",name,room}))};
  ws.onclose=()=>setStatus("● сервер недоступен");
  ws.onerror=()=>setStatus("● ошибка сервера");
  ws.onmessage=e=>handleSignal(JSON.parse(e.data));
}
function setStatus(t){$("connection").textContent=t}
function addMessage(m){
  if(m.type==="system"){const d=document.createElement("div");d.className="system";d.textContent=m.text;$("messages").append(d);return}
  const d=document.createElement("div");d.className="msg";
  d.innerHTML=`<div class="msg-avatar">${escapeHtml((m.name||"?")[0].toUpperCase())}</div><div><div><span class="msg-name">${escapeHtml(m.name||"User")}</span><span class="msg-time">${new Date(m.time||Date.now()).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}</span></div><div class="msg-text">${escapeHtml(m.text||"")}</div></div>`;
  $("messages").append(d);$("messages").scrollTop=$("messages").scrollHeight;
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("sendForm").onsubmit=e=>{e.preventDefault();const text=$("message").value.trim();if(text&&ws?.readyState===1){ws.send(JSON.stringify({type:"message",name,room,text}));$("message").value=""}};
$("mic").onclick=()=>startCall(false);
$("camera").onclick=()=>startCall(true);
$("hangup").onclick=hangup;

async function startCall(withVideo){
  try{
    if(!localStream) localStream=await navigator.mediaDevices.getUserMedia({audio:true,video:withVideo});
    else if(withVideo&&!localStream.getVideoTracks().length){
      const v=await navigator.mediaDevices.getUserMedia({audio:false,video:true});
      v.getVideoTracks().forEach(t=>localStream.addTrack(t));
    }
    addVideo("local",localStream,name,true);
    if(ws?.readyState===1) ws.send(JSON.stringify({type:"call-ready",room}));
  }catch(e){alert("Не удалось получить доступ к микрофону/камере: "+e.message)}
}
function addVideo(id,stream,label,muted=false){
  if(document.querySelector(`[data-video="${CSS.escape(id)}"]`))return;
  $("emptyCall").classList.add("hidden");
  const wrap=document.createElement("div");wrap.className="video-wrap";wrap.dataset.video=id;
  const v=document.createElement("video");v.autoplay=true;v.playsInline=true;v.muted=muted;v.srcObject=stream;
  const n=document.createElement("div");n.className="video-name";n.textContent=label;
  wrap.append(v,n);$("videos").append(wrap);
}
function removeVideo(id){document.querySelector(`[data-video="${CSS.escape(id)}"]`)?.remove()}
async function makeOffer(id){
  const pc=makePeer(id);
  const offer=await pc.createOffer();await pc.setLocalDescription(offer);
  ws.send(JSON.stringify({type:"offer",to:id,offer:pc.localDescription}));
}
function makePeer(id){
  if(peers.has(id))return peers.get(id);
  const pc=new RTCPeerConnection(config);peers.set(id,pc);
  if(localStream)localStream.getTracks().forEach(t=>pc.addTrack(t,localStream));
  pc.onicecandidate=e=>{if(e.candidate)ws.send(JSON.stringify({type:"ice",to:id,candidate:e.candidate}))};
  pc.ontrack=e=>addVideo(id,e.streams[0],"Участник");
  pc.onconnectionstatechange=()=>{if(["failed","closed","disconnected"].includes(pc.connectionState)){pc.close();peers.delete(id);removeVideo(id);updateCount()}};
  return pc;
}
async function handleSignal(m){
  if(m.type==="joined"){myId=m.id;(m.users||[]).forEach(u=>{if(u.id!==myId)makeOffer(u.id)});updateCount(m.users?.length||0);addMessage({type:"system",text:"Ты вошёл в #"+room});return}
  if(m.type==="message"){addMessage(m);return}
  if(m.type==="user-joined"){addMessage({type:"system",text:m.name+" подключился"});updateCount(m.count);if(localStream)makeOffer(m.id);return}
  if(m.type==="user-left"){addMessage({type:"system",text:m.name+" вышел"});if(peers.has(m.id)){peers.get(m.id).close();peers.delete(m.id)}removeVideo(m.id);updateCount(m.count);return}
  if(m.type==="call-ready"){if(localStream&&m.from!==myId)makeOffer(m.from);return}
  if(m.type==="offer"){
    const pc=makePeer(m.from);await pc.setRemoteDescription(m.offer);const answer=await pc.createAnswer();await pc.setLocalDescription(answer);ws.send(JSON.stringify({type:"answer",to:m.from,answer:pc.localDescription}));return
  }
  if(m.type==="answer"){const pc=peers.get(m.from);if(pc)await pc.setRemoteDescription(m.answer);return}
  if(m.type==="ice"){const pc=peers.get(m.from);if(pc&&m.candidate)try{await pc.addIceCandidate(m.candidate)}catch(e){}}
}
function updateCount(n){$("peerCount").textContent=n||0}
function hangup(){
  if(localStream){localStream.getTracks().forEach(t=>t.stop());localStream=null}
  peers.forEach(p=>p.close());peers.clear();$("videos").innerHTML="";$("emptyCall").classList.remove("hidden");updateCount(0);
}
window.addEventListener("beforeunload",()=>{try{ws?.close()}catch(e){}});